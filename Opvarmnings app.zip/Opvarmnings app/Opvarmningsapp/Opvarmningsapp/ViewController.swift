//
//  ViewController.swift
//  Opvarmningsapp
//
//  Created by Jesper Bertelsen on 24/01/2021.
//

import UIKit

class ViewController: UIViewController {

    //properties
    let maxTimes = 10
    var ønsketTal: Int = 0
    var nuværendeTal: Int = 0
    
    
    //Outlets
    @IBOutlet weak var playbtn: UIButton!
    @IBOutlet weak var NrToMultiply: UITextField!
    @IBOutlet weak var Logo: UIImageView!
    
    @IBOutlet weak var Beskrivelse: UILabel!
    @IBOutlet weak var Resultat: UILabel!
    @IBOutlet weak var TalGangeDet: UILabel!
    @IBOutlet weak var Addknap: UIButton!
    
    @IBAction func onAddbtnPress(_ sender: UIButton!) {
        nuværendeTal+=1
        opdater()
        if isGameOver() {
            restartgame()
        }
    }
    
    @IBAction func onplaybtn(_ sender: UIButton!) {
        if NrToMultiply.text != nil && NrToMultiply.text != "" {
            ønsketTal = Int(NrToMultiply.text!)!
            opdater()
            gameIsOn()
        }
    }
    
    func opdater() {
        Resultat.text = "\(nuværendeTal*ønsketTal)"
        TalGangeDet.text = "\(ønsketTal) * \(nuværendeTal) er :"
    }
    
    func isGameOver()-> Bool {
        if nuværendeTal >= maxTimes {
            return true
        } else {
            return false
        }
    }

    func restartgame(){
        ønsketTal = 0
        nuværendeTal = 0
        
        playbtn.isHidden=false
        NrToMultiply.isHidden=false
        Logo.isHidden=false
        
        Beskrivelse.isHidden=true
        Resultat.isHidden=true
        TalGangeDet.isHidden=true
        Addknap.isHidden=true
    }
    
    func gameIsOn(){
        playbtn.isHidden=true
        NrToMultiply.isHidden=true
        Logo.isHidden=true
        
        Beskrivelse.isHidden=false
        Resultat.isHidden=false
        TalGangeDet.isHidden=false
        Addknap.isHidden=false
    }
}



